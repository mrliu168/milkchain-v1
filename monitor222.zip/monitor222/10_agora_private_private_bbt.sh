docker rm -f agora_private_private_bbt 
docker run -i -t -d --network host --env LD_LIBRARY_PATH=/root/ --pid host --restart=unless-stopped --name agora_private_private_bbt \
-v `pwd`/log:/var/log/agora \
registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_private_rtn_bbt:release-v1_0_1-20230328 \
--local_ap_list 10.72.0.29 \
--influx_host 10.62.0.84 \
--test_mode private_to_private \
--appid 5ba7c3d54193499d931f3da82f3d8172
