docker rm -f agora_sre
docker run -i -t -d --restart=unless-stopped --name agora_sre \
-v `pwd`/log:/var/log/agora \
registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_sre:release-v1_0_0-20230330
